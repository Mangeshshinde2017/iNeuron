//JS program to find multiplication of 3 numbers

let x = multiplication(2, 5, 6)

function multiplication(num1, num2, num3) {

    return (num1 * num2 * num3);

}

console.log(x)