//JS program to add 2 numbers and display sum

let num1, num2

let sum = 0
function add(a, b){

    return a+b;
}

console.log (sum = add(-13, 5))