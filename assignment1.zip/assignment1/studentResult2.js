//JS program to decide grade as per marks obtained

let studentMarks = 70

//prompt("Enter students mark",0)

switch(studentMarks){
    case studentMarks : (studentMarks > 90);
        console.log("Grade A");
        break;
    case studentMarks : ( studentMarks < 90 && studentMarks >= 70) ;
        console.log("Grade B");
        break;
    case studentMarks : ( studentMarks < 70 && studentMarks >=50);
        console.log("Grade C");
        break;
    case studentMarks : (studentMarks < 50);
        console.log("Fail");
        break;

}
