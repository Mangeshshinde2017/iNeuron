//JS program to subract 2 numbers
let num1, num2

let sum = 0
function add(a, b){

    return a-b;
}

console.log (sum = add(45, 5))