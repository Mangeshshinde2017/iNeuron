//JS program to print fail if marks below 50

let studentMarks = prompt ("Enter student marks", 0);

if (studentMarks <= 50)
{
    console.log("Failed");
    
} else {
    console.log("Passed");
}

