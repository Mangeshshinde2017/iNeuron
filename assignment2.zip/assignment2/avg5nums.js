//JS program to find average of 5 numbers

let arr = [500, 500, 500, 200, 300]
let sum = 0

function calavg(arr) {

    arr.forEach(element => {
        sum = sum + element;
    })
    
    return  sum/5;

};


console.log(calavg(arr));