//JS program to concat 2 strings

let firstName = "Text1";
let lastName = "Text2";

console.log(`Concantation of the given 2 strings is ${firstName} ${lastName}`);