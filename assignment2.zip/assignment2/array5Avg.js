//JS program to calculate avg of 5 numbers in array

let arr = [1,11,111,222,555];

let sum = 0;

arr.forEach(element => {

    sum += element;
    
});

console.log(sum);

let avg = sum/5;

console.log(`Average is ${avg}`);