//JS program to find average of 5 numbers

let arr = [10, 20, 30, 40, 50]
let sum = 0

// function calavg(arr) {

//     arr.forEach(element => {
//         sum = sum + element;
//     })
    
//     return  sum

// };

for (let i = 0; i < arr.length; i++) {
    const element = arr[i];

    sum +=element;
}


console.log(`Sum of the 5 numbers is ${sum}`);