//JS program to find even numbers between 0 to 100

let arr = [];

for (let i = 1; i <= 100; i++) {
    
     if (i%2==!0){
        console.log(`This is a set of odd numbers ${i}`);
        console.log(i);
     }
    //  else{
    //     console.log(`No numbers are even`);
    //  }
    
}

