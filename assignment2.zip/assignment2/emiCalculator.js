//JS program to calculate emi

// EMI = P × r × (1 + r)n/((1 + r)n-1

let p = 1000000;
let r = 0.006;
let n = 120;
//let emi = p*(r*(pow((1+r),n)/((1+r)*n)))

let nume = Math.pow((1+r),n);
let deno = Math.pow((1+r),n)-1;

let emi = p*r*(nume/deno)

//let emi = p*(r*((Math.pow((1+r),n))/(Math.pow((1+r),(n-1)))));

console.log(emi);