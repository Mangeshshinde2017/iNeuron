//JS program to create 

let student = {
    Name : "Mahesh",
    College_Name : "Eng College",
    Location : "Mumbai",
    Pincode : "100001",
    Teachers_Details : {
        teacherName : "Madam",
        teacherPhone : 12345678,
        teacherSubjects : "English"
    }
}

console.log(`Student name is ${student.Name}`);
console.log(`Teachers name is ${student.Teachers_Details.teacherName}`);
